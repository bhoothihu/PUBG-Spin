<?php
$emailku = 'bhoothihu@gmail.com'; // GANTI EMAIL KAMU DISINI
?>